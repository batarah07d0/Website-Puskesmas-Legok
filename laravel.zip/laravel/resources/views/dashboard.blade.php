@extends('layouts.app')

@section('title', 'Dashboard - Halaman untuk mengedit Data ke Homepage')

@section('contents')
<div class="row">
    Dashboard
</div>
@endsection