<?php $__env->startSection('title', 'Dashboard - Halaman untuk mengedit Data ke Homepage'); ?>

<?php $__env->startSection('contents'); ?>
<div class="row">
    Dashboard
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\OneDrive\Documents\Project\Website-Puskesmas-Legok\laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>