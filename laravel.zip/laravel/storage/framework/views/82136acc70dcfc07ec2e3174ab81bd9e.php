<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>

<body>
    <div style="display:flex;">
        <br>
        <h1 style="justify-content: center; text-align:center; width:100%">
            Pendaftaran Online
        </h1>
        <h3>Nomor Antrian : 10101</h3>
        <p>Nomor BPJS : 234234234</p>
        <p>Nama : Rio</p>
        <p>Jenis Layanan : EEAAAAAA SEGGS</p>
        <p>Jam Layanan : ??? 6969</p>
    </div>
</body>

</html><?php /**PATH C:\Users\ACER\Documents\GitHub\Website-Puskesmas-Legok\laravel\resources\views/antriansukses-pdf.blade.php ENDPATH**/ ?>